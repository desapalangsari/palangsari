import sys
import sqlite3
from PyQt5.QtWidgets import QApplication, QMainWindow, QAction, QTabWidget, QWidget, QVBoxLayout, QLabel
from ap.views.rpjmdes_view import RPJMDesView
from ap.views.rkpdes_view import RKPDesView
from ap.views.agenda_surat_masuk_view import AgendaSuratMasukView
from ap.views.induk_penduduk_view import IndukPendudukView
from ap.views.mutasi_penduduk_view import MutasiPendudukView
from ap.views.keputusan_kades_view import KeputusanKadesView
from ap.views.kas_umum_view import KasUmumView
from ap.views.rencana_pembangunan_view import RencanaPembangunanView
from ap.views.agenda_surat_keluar_view import AgendaSuratKeluarView
from ap.views.inventaris_desa_view import InventarisDesaView
from ap.views.tanah_desa_view import TanahDesaView
from ap.views.peraturan_desa_view import PeraturanDesaView
from ap.views.lembaga_kemasyarakatan_view import LembagaKemasyarakatanView
from ap.views.aparatur_desa_view import AparaturDesaView
from ap.views.keluarga_miskin_view import KeluargaMiskinView
from ap.views.anak_yatim_piatu_view import AnakYatimPiatuView
from ap.views.data_disabilitas_view import DataDisabilitasView
from ap.views.data_lansia_view import DataLansiaView
from ap.views.data_kematian_view import DataKematianView
from ap.views.data_kelahiran_view import DataKelahiranView

DB_PATH = 'ap/database/administrasi_desa.db'
SCHEMA_PATH = 'ap/database/schema.sql'

# Inisialisasi database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    with open(SCHEMA_PATH, 'r') as f:
        conn.executescript(f.read())
    conn.close()

class BukuTab(QWidget):
    def __init__(self, judul):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"Tampilan untuk {judul}"))
        self.setLayout(layout)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Aplikasi Administrasi Desa")
        self.setGeometry(100, 100, 900, 600)
        self.init_ui()

    def init_ui(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu('File')
        exit_action = QAction('Keluar', self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        tabs = QTabWidget()
        tabs.addTab(RPJMDesView(), "RPJMDes")
        tabs.addTab(RKPDesView(), "RKPDes")
        tabs.addTab(AgendaSuratMasukView(), "Agenda Surat Masuk")
        tabs.addTab(IndukPendudukView(), "Induk Penduduk")
        tabs.addTab(MutasiPendudukView(), "Mutasi Penduduk")
        tabs.addTab(KeputusanKadesView(), "Keputusan Kepala Desa")
        tabs.addTab(KasUmumView(), "Kas Umum")
        tabs.addTab(RencanaPembangunanView(), "Rencana Pembangunan")
        tabs.addTab(AgendaSuratKeluarView(), "Agenda Surat Keluar")
        tabs.addTab(InventarisDesaView(), "Inventaris Desa")
        tabs.addTab(TanahDesaView(DB_PATH), "Buku Tanah Desa")
        tabs.addTab(PeraturanDesaView(DB_PATH), "Buku Peraturan Desa")
        tabs.addTab(LembagaKemasyarakatanView(DB_PATH), "Buku Lembaga Kemasyarakatan Desa")
        tabs.addTab(AparaturDesaView(DB_PATH), "Buku Aparatur Pemerintah Desa")
        tabs.addTab(KeluargaMiskinView(DB_PATH), "Buku Data Keluarga Miskin")
        tabs.addTab(AnakYatimPiatuView(DB_PATH), "Buku Data Anak Yatim dan Piatu")
        tabs.addTab(DataDisabilitasView(DB_PATH), "Buku Data Disabilitas")
        tabs.addTab(DataLansiaView(DB_PATH), "Buku Data Lansia")
        tabs.addTab(DataKematianView(DB_PATH), "Buku Data Kematian")
        tabs.addTab(DataKelahiranView(DB_PATH), "Buku Data Kelahiran")
        # Tambahkan tab lain sesuai kebutuhan
        self.setCentralWidget(tabs)

if __name__ == "__main__":
    init_db()
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
