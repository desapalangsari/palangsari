import sqlite3

class AparaturDesaModel:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.create_table()

    def create_table(self):
        self.conn.execute('''CREATE TABLE IF NOT EXISTS aparatur_desa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            jabatan TEXT,
            tempat_lahir TEXT,
            tanggal_lahir TEXT,
            pendidikan TEXT,
            tahun_menjabat INTEGER,
            alamat TEXT,
            keterangan TEXT
        )''')
        self.conn.commit()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute('''INSERT INTO aparatur_desa (nama, jabatan, tempat_lahir, tanggal_lahir, pendidikan, tahun_menjabat, alamat, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', data)
        self.conn.commit()

    def get_all(self):
        cur = self.conn.cursor()
        cur.execute('SELECT * FROM aparatur_desa')
        return cur.fetchall()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute('''UPDATE aparatur_desa SET nama=?, jabatan=?, tempat_lahir=?, tanggal_lahir=?, pendidikan=?, tahun_menjabat=?, alamat=?, keterangan=? WHERE id=?''', (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute('DELETE FROM aparatur_desa WHERE id=?', (id,))
        self.conn.commit()
