import sqlite3

DB_PATH = 'ap/database/administrasi_desa.db'

class RencanaPembangunanModel:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row

    def all(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM rencana_pembangunan ORDER BY tahun DESC, id DESC")
        return cur.fetchall()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO rencana_pembangunan (tahun, bidang, sub_bidang, nama_kegiatan, lokasi, sasaran, volume, manfaat, perkiraan_biaya, sumber_dana, pelaksana, keterangan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        self.conn.commit()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE rencana_pembangunan SET tahun=?, bidang=?, sub_bidang=?, nama_kegiatan=?, lokasi=?, sasaran=?, volume=?, manfaat=?, perkiraan_biaya=?, sumber_dana=?, pelaksana=?, keterangan=? WHERE id=?
        """, (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM rencana_pembangunan WHERE id=?", (id,))
        self.conn.commit()

    def get_by_id(self, id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM rencana_pembangunan WHERE id=?", (id,))
        return cur.fetchone()

    def close(self):
        self.conn.close()
