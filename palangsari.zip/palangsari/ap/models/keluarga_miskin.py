import sqlite3

class KeluargaMiskinModel:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.create_table()

    def create_table(self):
        self.conn.execute('''CREATE TABLE IF NOT EXISTS keluarga_miskin (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_kepala_keluarga TEXT,
            alamat TEXT,
            jumlah_anggota INTEGER,
            kriteria TEXT,
            bantuan TEXT,
            keterangan TEXT
        )''')
        self.conn.commit()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute('''INSERT INTO keluarga_miskin (nama_kepala_keluarga, alamat, jumlah_anggota, kriteria, bantuan, keterangan) VALUES (?, ?, ?, ?, ?, ?)''', data)
        self.conn.commit()

    def get_all(self):
        cur = self.conn.cursor()
        cur.execute('SELECT * FROM keluarga_miskin')
        return cur.fetchall()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute('''UPDATE keluarga_miskin SET nama_kepala_keluarga=?, alamat=?, jumlah_anggota=?, kriteria=?, bantuan=?, keterangan=? WHERE id=?''', (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute('DELETE FROM keluarga_miskin WHERE id=?', (id,))
        self.conn.commit()
