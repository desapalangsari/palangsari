import sqlite3

class AnakYatimPiatuModel:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.create_table()

    def create_table(self):
        self.conn.execute('''CREATE TABLE IF NOT EXISTS anak_yatim_piatu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_anak TEXT,
            nama_orangtua TEXT,
            alamat TEXT,
            tanggal_lahir TEXT,
            status TEXT,
            bantuan TEXT,
            keterangan TEXT
        )''')
        self.conn.commit()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute('''INSERT INTO anak_yatim_piatu (nama_anak, nama_orangtua, alamat, tanggal_lahir, status, bantuan, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?)''', data)
        self.conn.commit()

    def get_all(self):
        cur = self.conn.cursor()
        cur.execute('SELECT * FROM anak_yatim_piatu')
        return cur.fetchall()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute('''UPDATE anak_yatim_piatu SET nama_anak=?, nama_orangtua=?, alamat=?, tanggal_lahir=?, status=?, bantuan=?, keterangan=? WHERE id=?''', (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute('DELETE FROM anak_yatim_piatu WHERE id=?', (id,))
        self.conn.commit()
