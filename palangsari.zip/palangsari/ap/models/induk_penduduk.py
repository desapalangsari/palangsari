import sqlite3

DB_PATH = 'ap/database/administrasi_desa.db'

class IndukPendudukModel:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row

    def all(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM induk_penduduk ORDER BY nama ASC, id DESC")
        return cur.fetchall()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO induk_penduduk (nama, nik, kk, alamat, jenis_kelamin, tempat_lahir, tanggal_lahir, agama, pendidikan, pekerjaan, status_perkawinan, status_hubungan_keluarga, kewarganegaraan, keterangan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        self.conn.commit()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE induk_penduduk SET nama=?, nik=?, kk=?, alamat=?, jenis_kelamin=?, tempat_lahir=?, tanggal_lahir=?, agama=?, pendidikan=?, pekerjaan=?, status_perkawinan=?, status_hubungan_keluarga=?, kewarganegaraan=?, keterangan=? WHERE id=?
        """, (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM induk_penduduk WHERE id=?", (id,))
        self.conn.commit()

    def get_by_id(self, id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM induk_penduduk WHERE id=?", (id,))
        return cur.fetchone()

    def close(self):
        self.conn.close()
