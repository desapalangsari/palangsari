import sqlite3

DB_PATH = 'ap/database/administrasi_desa.db'

class AgendaSuratMasukModel:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row

    def all(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM agenda_surat_masuk ORDER BY tanggal DESC, id DESC")
        return cur.fetchall()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO agenda_surat_masuk (tanggal, nomor_surat, pengirim, perihal, keterangan)
            VALUES (?, ?, ?, ?, ?)
        """, data)
        self.conn.commit()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE agenda_surat_masuk SET tanggal=?, nomor_surat=?, pengirim=?, perihal=?, keterangan=? WHERE id=?
        """, (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM agenda_surat_masuk WHERE id=?", (id,))
        self.conn.commit()

    def get_by_id(self, id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM agenda_surat_masuk WHERE id=?", (id,))
        return cur.fetchone()

    def close(self):
        self.conn.close()
