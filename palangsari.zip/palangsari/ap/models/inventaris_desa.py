import sqlite3

DB_PATH = 'ap/database/administrasi_desa.db'

class InventarisDesaModel:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row

    def all(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM inventaris_desa ORDER BY id DESC")
        return cur.fetchall()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO inventaris_desa (nama_barang, jumlah, satuan, tahun_perolehan, asal, kondisi, lokasi, keterangan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        self.conn.commit()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE inventaris_desa SET nama_barang=?, jumlah=?, satuan=?, tahun_perolehan=?, asal=?, kondisi=?, lokasi=?, keterangan=? WHERE id=?
        """, (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM inventaris_desa WHERE id=?", (id,))
        self.conn.commit()

    def get_by_id(self, id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM inventaris_desa WHERE id=?", (id,))
        return cur.fetchone()

    def close(self):
        self.conn.close()
