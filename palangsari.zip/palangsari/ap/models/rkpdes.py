import sqlite3

DB_PATH = 'ap/database/administrasi_desa.db'

class RKPDesModel:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row

    def all(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM rkpdes ORDER BY tahun, id")
        return cur.fetchall()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO rkpdes (tahun, kegiatan, lokasi, volume, satuan, sasaran, anggaran, sumber_dana, pelaksana, waktu_pelaksanaan, target, keterangan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        self.conn.commit()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE rkpdes SET tahun=?, kegiatan=?, lokasi=?, volume=?, satuan=?, sasaran=?, anggaran=?, sumber_dana=?, pelaksana=?, waktu_pelaksanaan=?, target=?, keterangan=? WHERE id=?
        """, (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM rkpdes WHERE id=?", (id,))
        self.conn.commit()

    def get_by_id(self, id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM rkpdes WHERE id=?", (id,))
        return cur.fetchone()

    def close(self):
        self.conn.close()
