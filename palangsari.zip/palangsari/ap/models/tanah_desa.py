import sqlite3

class TanahDesaModel:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.create_table()

    def create_table(self):
        self.conn.execute('''CREATE TABLE IF NOT EXISTS tanah_desa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nomor_bidang TEXT,
            luas REAL,
            status_tanah TEXT,
            penggunaan TEXT,
            asal_perolehan TEXT,
            tahun_perolehan INTEGER,
            lokasi TEXT,
            batas_utara TEXT,
            batas_selatan TEXT,
            batas_timur TEXT,
            batas_barat TEXT,
            keterangan TEXT
        )''')
        self.conn.commit()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute('''INSERT INTO tanah_desa (nomor_bidang, luas, status_tanah, penggunaan, asal_perolehan, tahun_perolehan, lokasi, batas_utara, batas_selatan, batas_timur, batas_barat, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', data)
        self.conn.commit()

    def get_all(self):
        cur = self.conn.cursor()
        cur.execute('SELECT * FROM tanah_desa')
        return cur.fetchall()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute('''UPDATE tanah_desa SET nomor_bidang=?, luas=?, status_tanah=?, penggunaan=?, asal_perolehan=?, tahun_perolehan=?, lokasi=?, batas_utara=?, batas_selatan=?, batas_timur=?, batas_barat=?, keterangan=? WHERE id=?''', (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute('DELETE FROM tanah_desa WHERE id=?', (id,))
        self.conn.commit()
