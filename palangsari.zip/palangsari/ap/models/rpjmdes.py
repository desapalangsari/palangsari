import sqlite3

DB_PATH = 'ap/database/administrasi_desa.db'

class RPJMDesModel:
    def get_by_id(self, id):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM rpjmdes WHERE id=?", (id,))
        return cur.fetchone()
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.conn.row_factory = sqlite3.Row

    def all(self):
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM rpjmdes ORDER BY tahun, id")
        return cur.fetchall()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute("""
            INSERT INTO rpjmdes (tahun, bidang, sub_bidang, nama_kegiatan, lokasi, sasaran, volume, manfaat, perkiraan_biaya, sumber_dana, pelaksana, keterangan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        self.conn.commit()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE rpjmdes SET tahun=?, bidang=?, sub_bidang=?, nama_kegiatan=?, lokasi=?, sasaran=?, volume=?, manfaat=?, perkiraan_biaya=?, sumber_dana=?, pelaksana=?, keterangan=? WHERE id=?
        """, (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute("DELETE FROM rpjmdes WHERE id=?", (id,))
        self.conn.commit()

    def close(self):
        self.conn.close()
