import sqlite3

class DataKelahiranModel:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.create_table()

    def create_table(self):
        self.conn.execute('''CREATE TABLE IF NOT EXISTS data_kelahiran (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            jenis_kelamin TEXT,
            alamat TEXT,
            tanggal_lahir TEXT,
            nama_ayah TEXT,
            nama_ibu TEXT,
            keterangan TEXT
        )''')
        self.conn.commit()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute('''INSERT INTO data_kelahiran (nama, jenis_kelamin, alamat, tanggal_lahir, nama_ayah, nama_ibu, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?)''', data)
        self.conn.commit()

    def get_all(self):
        cur = self.conn.cursor()
        cur.execute('SELECT * FROM data_kelahiran')
        return cur.fetchall()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute('''UPDATE data_kelahiran SET nama=?, jenis_kelamin=?, alamat=?, tanggal_lahir=?, nama_ayah=?, nama_ibu=?, keterangan=? WHERE id=?''', (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute('DELETE FROM data_kelahiran WHERE id=?', (id,))
        self.conn.commit()
