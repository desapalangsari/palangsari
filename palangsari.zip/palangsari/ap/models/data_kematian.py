import sqlite3

class DataKematianModel:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)
        self.create_table()

    def create_table(self):
        self.conn.execute('''CREATE TABLE IF NOT EXISTS data_kematian (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            jenis_kelamin TEXT,
            alamat TEXT,
            tanggal_lahir TEXT,
            tanggal_meninggal TEXT,
            sebab TEXT,
            keterangan TEXT
        )''')
        self.conn.commit()

    def add(self, data):
        cur = self.conn.cursor()
        cur.execute('''INSERT INTO data_kematian (nama, jenis_kelamin, alamat, tanggal_lahir, tanggal_meninggal, sebab, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?)''', data)
        self.conn.commit()

    def get_all(self):
        cur = self.conn.cursor()
        cur.execute('SELECT * FROM data_kematian')
        return cur.fetchall()

    def update(self, id, data):
        cur = self.conn.cursor()
        cur.execute('''UPDATE data_kematian SET nama=?, jenis_kelamin=?, alamat=?, tanggal_lahir=?, tanggal_meninggal=?, sebab=?, keterangan=? WHERE id=?''', (*data, id))
        self.conn.commit()

    def delete(self, id):
        cur = self.conn.cursor()
        cur.execute('DELETE FROM data_kematian WHERE id=?', (id,))
        self.conn.commit()
