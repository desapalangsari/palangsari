import sqlite3
from ap.models.rpjmdes import RPJMDesModel

TEMPLATE_PATH = 'ap/templates/rpjmdes_template.txt'

class RPJMDesExporter:
    def __init__(self):
        self.model = RPJMDesModel()

    def generate_matriks(self):
        rows = self.model.all()
        matriks = ""
        for i, row in enumerate(rows, 1):
            matriks += f"{i}\t{row['bidang']} / {row['sub_bidang']}\t{row['nama_kegiatan']}\t{row['lokasi']}\t{row['sasaran']}\t{row['volume']}\t{row['perkiraan_biaya']}\t{row['sumber_dana']}\t{row['tahun']}\t{row['pelaksana']}\n"
        return matriks

    def export(self, data):
        with open(TEMPLATE_PATH, 'r') as f:
            template = f.read()
        output = template.format(
            tahun_awal=data['tahun_awal'],
            tahun_akhir=data['tahun_akhir'],
            nama_desa=data['nama_desa'],
            nama_kecamatan=data['nama_kecamatan'],
            nama_kabupaten=data['nama_kabupaten'],
            tahun_penyusunan=data['tahun_penyusunan'],
            nomor_perdes=data['nomor_perdes'],
            tanggal_musdes=data['tanggal_musdes'],
            tanggal_penetapan=data['tanggal_penetapan'],
            matriks_kegiatan=self.generate_matriks()
        )
        with open('RPJMDes_{nama_desa}_{tahun_awal}-{tahun_akhir}.txt'.format(**data), 'w') as out:
            out.write(output)
        return 'RPJMDes_{nama_desa}_{tahun_awal}-{tahun_akhir}.txt'.format(**data)
