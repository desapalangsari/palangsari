from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTableWidget, QPushButton, QHBoxLayout, QTableWidgetItem, QMessageBox, QLineEdit, QLabel, QFormLayout, QDialog
import pandas as pd
from ap.models.data_kelahiran import DataKelahiranModel

class DataKelahiranView(QWidget):
    def __init__(self, db_path):
        super().__init__()
        self.model = DataKelahiranModel(db_path)
        self.init_ui()
        self.load_data()

    def init_ui(self):
        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "ID", "Nama", "Jenis Kelamin", "Alamat", "Tanggal Lahir", "Nama Ayah", "Nama Ibu", "Keterangan"
        ])
        layout.addWidget(self.table)

        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton("Tambah")
        self.edit_btn = QPushButton("Edit")
        self.delete_btn = QPushButton("Hapus")
        self.export_btn = QPushButton("Export CSV")
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.edit_btn)
        btn_layout.addWidget(self.delete_btn)
        btn_layout.addWidget(self.export_btn)
        layout.addLayout(btn_layout)

        self.add_btn.clicked.connect(self.add_data)
        self.edit_btn.clicked.connect(self.edit_data)
        self.delete_btn.clicked.connect(self.delete_data)
        self.export_btn.clicked.connect(self.export_csv)

        self.setLayout(layout)

    def load_data(self):
        self.table.setRowCount(0)
        data = self.model.get_all()
        for row_idx, row in enumerate(data):
            self.table.insertRow(row_idx)
            for col_idx, item in enumerate(row):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(str(item)))

    def add_data(self):
        dialog = DataKelahiranDialog()
        if dialog.exec_():
            self.model.add(dialog.get_data())
            self.load_data()

    def edit_data(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Peringatan", "Pilih baris yang akan diedit.")
            return
        id_val = int(self.table.item(selected, 0).text())
        current_data = [self.table.item(selected, i).text() for i in range(1, 8)]
        dialog = DataKelahiranDialog(current_data)
        if dialog.exec_():
            self.model.update(id_val, dialog.get_data())
            self.load_data()

    def delete_data(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Peringatan", "Pilih baris yang akan dihapus.")
            return
        id_val = int(self.table.item(selected, 0).text())
        self.model.delete(id_val)
        self.load_data()

    def export_csv(self):
        data = self.model.get_all()
        df = pd.DataFrame(data, columns=[
            "ID", "Nama", "Jenis Kelamin", "Alamat", "Tanggal Lahir", "Nama Ayah", "Nama Ibu", "Keterangan"
        ])
        df.to_csv("data_kelahiran.csv", index=False)
        QMessageBox.information(self, "Export", "Data berhasil diexport ke data_kelahiran.csv")

class DataKelahiranDialog(QDialog):
    def __init__(self, data=None):
        super().__init__()
        self.setWindowTitle("Input Data Kelahiran")
        self.inputs = []
        form = QFormLayout()
        labels = [
            "Nama", "Jenis Kelamin", "Alamat", "Tanggal Lahir", "Nama Ayah", "Nama Ibu", "Keterangan"
        ]
        for i, label in enumerate(labels):
            inp = QLineEdit()
            if data:
                inp.setText(str(data[i]))
            form.addRow(QLabel(label), inp)
            self.inputs.append(inp)
        self.setLayout(form)

    def get_data(self):
        return [inp.text() for inp in self.inputs]
