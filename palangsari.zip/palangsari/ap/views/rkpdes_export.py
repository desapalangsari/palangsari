import sqlite3
from ap.models.rkpdes import RKPDesModel

TEMPLATE_PATH = 'ap/templates/rkpdes_template.txt'

class RKPDesExporter:
    def __init__(self):
        self.model = RKPDesModel()

    def generate_matriks_kegiatan(self):
        rows = self.model.all()
        matriks = ""
        for i, row in enumerate(rows, 1):
            matriks += f"{i}\t{row['bidang'] if 'bidang' in row.keys() else ''} / {row['sub_bidang'] if 'sub_bidang' in row.keys() else ''}\t{row['kegiatan']}\t{row['lokasi']}\t{row['volume']}\t{row['sasaran']}\t{row['waktu_pelaksanaan'] if 'waktu_pelaksanaan' in row.keys() else ''}\t{row['anggaran']} & {row['sumber_dana']}\t{row['pelaksana']}\t{row['keterangan']}\n"
        return matriks

    def export(self, data):
        with open(TEMPLATE_PATH, 'r') as f:
            template = f.read()
        output = template.format(
            tahun_anggaran=data['tahun_anggaran'],
            nama_desa=data['nama_desa'],
            nama_kecamatan=data['nama_kecamatan'],
            nama_kabupaten=data['nama_kabupaten'],
            nomor_perdes=data['nomor_perdes'],
            tanggal_musdes=data['tanggal_musdes'],
            tanggal_pengundangan=data['tanggal_pengundangan'],
            tanggal_penetapan=data['tanggal_penetapan'],
            matriks_evaluasi=data.get('matriks_evaluasi', ''),
            matriks_pendapatan=data.get('matriks_pendapatan', ''),
            matriks_belanja=data.get('matriks_belanja', ''),
            matriks_kegiatan=self.generate_matriks_kegiatan()
        )
        filename = 'RKPDes_{nama_desa}_{tahun_anggaran}.txt'.format(**data)
        with open(filename, 'w') as out:
            out.write(output)
        return filename
