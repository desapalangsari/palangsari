from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QHBoxLayout, QDialog, QLabel, QLineEdit, QFormLayout, QMessageBox
from ap.models.kas_umum import KasUmumModel

class KasUmumView(QWidget):
    def __init__(self):
        super().__init__()
        self.model = KasUmumModel()
        self.init_ui()
        self.load_data()

    def init_ui(self):
        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "ID", "Tanggal", "Uraian", "Penerimaan", "Pengeluaran", "Saldo", "Keterangan"
        ])
        layout.addWidget(self.table)

        btn_layout = QHBoxLayout()
        self.btn_add = QPushButton("Tambah Data")
        self.btn_add.clicked.connect(self.show_add_dialog)
        btn_layout.addWidget(self.btn_add)

        self.btn_edit = QPushButton("Edit Data")
        self.btn_edit.clicked.connect(self.show_edit_dialog)
        btn_layout.addWidget(self.btn_edit)

        self.btn_delete = QPushButton("Hapus Data")
        self.btn_delete.clicked.connect(self.delete_data)
        btn_layout.addWidget(self.btn_delete)

        self.btn_export = QPushButton("Ekspor ke CSV")
        self.btn_export.clicked.connect(self.export_csv)
        btn_layout.addWidget(self.btn_export)

        layout.addLayout(btn_layout)
        self.setLayout(layout)

    def load_data(self):
        data = self.model.all()
        self.table.setRowCount(len(data))
        for row_idx, row in enumerate(data):
            for col_idx, key in enumerate(row.keys()):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(str(row[key])))

    def show_add_dialog(self):
        dialog = KasUmumFormDialog(self.model, self)
        if dialog.exec_():
            self.load_data()

    def show_edit_dialog(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Pilih Data", "Pilih baris yang akan diedit.")
            return
        id_item = self.table.item(selected, 0)
        if not id_item:
            QMessageBox.warning(self, "Error", "ID tidak ditemukan.")
            return
        id_val = int(id_item.text())
        dialog = KasUmumFormDialog(self.model, self, edit_id=id_val)
        if dialog.exec_():
            self.load_data()

    def delete_data(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Pilih Data", "Pilih baris yang akan dihapus.")
            return
        id_item = self.table.item(selected, 0)
        if not id_item:
            QMessageBox.warning(self, "Error", "ID tidak ditemukan.")
            return
        id_val = int(id_item.text())
        reply = QMessageBox.question(self, "Konfirmasi", "Yakin hapus data?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.model.delete(id_val)
            self.load_data()

    def export_csv(self):
        import pandas as pd
        data = self.model.all()
        df = pd.DataFrame([dict(row) for row in data])
        df.to_csv("kas_umum_export.csv", index=False)
        QMessageBox.information(self, "Ekspor", "Data berhasil diekspor ke kas_umum_export.csv")

class KasUmumFormDialog(QDialog):
    def __init__(self, model, parent=None, edit_id=None):
        super().__init__(parent)
        self.model = model
        self.edit_id = edit_id
        self.setWindowTitle("Edit Data Kas Umum" if edit_id else "Tambah Data Kas Umum")
        self.init_ui()

    def init_ui(self):
        layout = QFormLayout()
        self.inputs = {}
        self.fields = [
            ("tanggal", "Tanggal"), ("uraian", "Uraian"), ("penerimaan", "Penerimaan"), ("pengeluaran", "Pengeluaran"), ("saldo", "Saldo"), ("keterangan", "Keterangan")
        ]
        for key, label in self.fields:
            inp = QLineEdit()
            layout.addRow(QLabel(label), inp)
            self.inputs[key] = inp
        if self.edit_id:
            row = self.model.get_by_id(self.edit_id)
            if row:
                for idx, (key, _) in enumerate(self.fields):
                    self.inputs[key].setText(str(row[key]))
        self.btn_save = QPushButton("Simpan")
        self.btn_save.clicked.connect(self.save)
        layout.addRow(self.btn_save)
        self.setLayout(layout)

    def save(self):
        try:
            data = [self.inputs[f].text() for f, _ in self.fields]
            if self.edit_id:
                self.model.update(self.edit_id, data)
            else:
                self.model.add(data)
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
