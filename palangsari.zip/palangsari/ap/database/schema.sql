-- Skema database SQLite untuk aplikasi administrasi desa

-- Tabel RPJMDes
CREATE TABLE IF NOT EXISTS rpjmdes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tahun INTEGER,
    bidang TEXT,
    sub_bidang TEXT,
    nama_kegiatan TEXT,
    lokasi TEXT,
    sasaran TEXT,
    volume TEXT,
    manfaat TEXT,
    perkiraan_biaya REAL,
    sumber_dana TEXT,
    pelaksana TEXT,
    keterangan TEXT
);

-- Tabel RKPDes
CREATE TABLE IF NOT EXISTS rkpdes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tahun INTEGER,
    kegiatan TEXT,
    lokasi TEXT,
    volume TEXT,
    sasaran TEXT,
    anggaran REAL,
    sumber_dana TEXT,
    pelaksana TEXT,
    waktu_pelaksanaan TEXT,
    target TEXT,
    keterangan TEXT
);

-- Tabel Buku Agenda Surat Masuk
CREATE TABLE IF NOT EXISTS agenda_surat_masuk (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tanggal TEXT,
    nomor_surat TEXT,
    pengirim TEXT,
    perihal TEXT,
    keterangan TEXT
);

-- Tabel Buku Peraturan Desa
CREATE TABLE IF NOT EXISTS peraturan_desa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nomor_peraturan TEXT,
    tanggal_ditetapkan TEXT,
    tentang TEXT,
    uraian_singkat TEXT,
    tanggal_diundangkan TEXT,
    keterangan TEXT
);

-- Tabel Buku Agenda Surat Keluar
CREATE TABLE IF NOT EXISTS agenda_surat_keluar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tanggal TEXT,
    nomor_surat TEXT,
    tujuan TEXT,
    perihal TEXT,
    keterangan TEXT
);


-- Tabel Buku Induk Penduduk
CREATE TABLE IF NOT EXISTS induk_penduduk (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    nik TEXT,
    kk TEXT,
    alamat TEXT,
    jenis_kelamin TEXT,
    tempat_lahir TEXT,
    tanggal_lahir TEXT,
    agama TEXT,
    pendidikan TEXT,
    pekerjaan TEXT,
    status_perkawinan TEXT,
    status_hubungan_keluarga TEXT,
    kewarganegaraan TEXT,
    keterangan TEXT
);

-- Tabel Buku Mutasi Penduduk
CREATE TABLE IF NOT EXISTS mutasi_penduduk (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    nik TEXT,
    kk TEXT,
    jenis_mutasi TEXT,
    tanggal_mutasi TEXT,
    alamat_asal TEXT,
    alamat_tujuan TEXT,
    keterangan TEXT
);

-- Tabel Buku Keputusan Kepala Desa
CREATE TABLE IF NOT EXISTS keputusan_kades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nomor_keputusan TEXT,
    tanggal TEXT,
    perihal TEXT,
    keterangan TEXT
);

-- Tabel Buku Kas Umum
CREATE TABLE IF NOT EXISTS kas_umum (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tanggal TEXT,
    uraian TEXT,
    penerimaan REAL,
    pengeluaran REAL,
    saldo REAL,
    keterangan TEXT
);

CREATE TABLE IF NOT EXISTS rencana_pembangunan (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tahun INTEGER,
    bidang TEXT,
    sub_bidang TEXT,
    nama_kegiatan TEXT,
    lokasi TEXT,
    sasaran TEXT,
    volume TEXT,
    manfaat TEXT,
    perkiraan_biaya REAL,
    sumber_dana TEXT,
    pelaksana TEXT,
    keterangan TEXT
);

CREATE TABLE IF NOT EXISTS inventaris_desa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_barang TEXT,
    jumlah INTEGER,
    satuan TEXT,
    tahun_perolehan INTEGER,
    asal TEXT,
    kondisi TEXT,
    lokasi TEXT,
    keterangan TEXT
);

-- Tabel Buku Tanah Desa
CREATE TABLE IF NOT EXISTS tanah_desa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nomor_bidang TEXT,
    luas REAL,
    status_tanah TEXT,
    penggunaan TEXT,
    asal_perolehan TEXT,
    tahun_perolehan INTEGER,
    lokasi TEXT,
    batas_utara TEXT,
    batas_selatan TEXT,
    batas_timur TEXT,
    batas_barat TEXT,
    keterangan TEXT
);

-- Tabel Buku Lembaga Kemasyarakatan Desa
CREATE TABLE IF NOT EXISTS lembaga_kemasyarakatan (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_lembaga TEXT,
    nama_pimpinan TEXT,
    tahun_pembentukan INTEGER,
    bidang_kegiatan TEXT,
    alamat TEXT,
    keterangan TEXT
);

-- Tabel Buku Aparatur Pemerintah Desa
CREATE TABLE IF NOT EXISTS aparatur_desa (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    jabatan TEXT,
    tempat_lahir TEXT,
    tanggal_lahir TEXT,
    pendidikan TEXT,
    tahun_menjabat INTEGER,
    alamat TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Keluarga Miskin
CREATE TABLE IF NOT EXISTS keluarga_miskin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_kepala_keluarga TEXT,
    alamat TEXT,
    jumlah_anggota INTEGER,
    kriteria TEXT,
    bantuan TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Anak Yatim dan Piatu
CREATE TABLE IF NOT EXISTS anak_yatim_piatu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama_anak TEXT,
    nama_orangtua TEXT,
    alamat TEXT,
    tanggal_lahir TEXT,
    status TEXT,
    bantuan TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Disabilitas
CREATE TABLE IF NOT EXISTS data_disabilitas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    jenis_kelamin TEXT,
    alamat TEXT,
    tanggal_lahir TEXT,
    jenis_disabilitas TEXT,
    bantuan TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Lansia
CREATE TABLE IF NOT EXISTS data_lansia (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    jenis_kelamin TEXT,
    alamat TEXT,
    tanggal_lahir TEXT,
    bantuan TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Kematian
CREATE TABLE IF NOT EXISTS data_kematian (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    jenis_kelamin TEXT,
    alamat TEXT,
    tanggal_lahir TEXT,
    tanggal_meninggal TEXT,
    sebab TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Kelahiran
CREATE TABLE IF NOT EXISTS data_kelahiran (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    jenis_kelamin TEXT,
    alamat TEXT,
    tanggal_lahir TEXT,
    nama_ayah TEXT,
    nama_ibu TEXT,
    keterangan TEXT
);

-- Tabel Buku Data Pendatang
CREATE TABLE IF NOT EXISTS data_pendatang (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nama TEXT,
    jenis_kelamin TEXT,
    alamat_asal TEXT,
    alamat_tujuan TEXT,
    tanggal_datang TEXT,
    alasan TEXT,
    keterangan TEXT
);
