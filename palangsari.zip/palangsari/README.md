# Aplikasi Administrasi Desa

Aplikasi desktop Windows (Python, SQLite, PyQt5) untuk pengelolaan buku administrasi desa sesuai Permendagri 47/2016.

## Fitur Utama
- Multi-buku administrasi (RPJMDes, RKPDes, Agenda Surat Masuk/Keluar, dst)
- Database SQLite
- Tampilan desktop modern (PyQt5)
- Ekspor data ke Excel/CSV

## Instalasi
1. Install Python 3.11+ dan pip
2. Install dependensi:
   ```bash
   pip install -r requirements.txt
   ```
3. Jalankan aplikasi:
   ```bash
   python ap/main.py
   ```

## Struktur Folder
- ap/database/schema.sql : Skema database
- ap/main.py : Entry point aplikasi
- ap/models/ : Model data
- ap/views/ : Tampilan per buku

## Pengembangan Lanjutan
- Tambahkan model dan tampilan untuk setiap buku administrasi
- Integrasi fitur tambah/edit/hapus/cari data
- Ekspor data

## Referensi
- Permendagri 47/2016
- Permendagri 114/2014
# palangsari